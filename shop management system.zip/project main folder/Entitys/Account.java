package Entitys;
import classes.*;
import java.lang.*;
import java.util.*;
import java.io.*;


public class Account
{
	private String username;
	private String userpass;
	
	
	File file;
	FileWriter fwrite;
	Scanner sc;
	public Account()
	{
		this.username="";
	}
	public Account(String username,String userpass)
	{
		this.username=username;
		this.userpass=userpass;
		
	}
	public void setUsername(String username)
	{
		this.username=username;
	}
	public void setUserpass(String userpass)
	{
		this.userpass=userpass;
	}
	
	public String getUsername()
	{
		return username;
	}
	public String getUserpass()
	{
		return userpass;
	}
	
	
	
	public void addAccount()
	{
		try
		{
			file=new File("./Datas/Data.txt");
			file.createNewFile();
			
			fwrite=new FileWriter(file,true);
			fwrite.write(getUsername()+"\t");
			fwrite.write(getUserpass()+"\n");
			
			fwrite.flush();
			fwrite.close();
			
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
		
			public boolean checkAccount(String username,String userpass)
		{
			boolean flag=false;
			try
			{
				file=new File("./Datas/Data.txt");
				sc=new Scanner(file);
				while (sc.hasNextLine())
				{
					String line=sc.nextLine();
					String[] value=line.split("\t");
					if(value[0].equals(username)&&value[1].equals(userpass))
					{
					flag=true;
					}
				}
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
			return flag;
		}
	
}
			