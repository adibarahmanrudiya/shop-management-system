import classes.*;
import Entitys.*;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;


public class Start 
{
	public static void main(String[] args)
	{
		Rudiyaframe f1=new Rudiyaframe();
		f1.setVisible(true);
		
		//FrameInttrroo f1=new FrameInttrroo();
		//f1.setVisible(true);
		
		//JarinFrame j1=new JarinFrame();
		//j1.setVisible(true);
		//Paymentframe p1=new Paymentframe();
		//p1.setVisible(true);
		
		//Signinframe s1=new Signinframe();
		//s1.setVisible(true);
		//RegisterFrame r1=new RegisterFrame();
		//r1.setVisible(true); 
	}
}