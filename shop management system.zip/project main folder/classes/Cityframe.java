package classes;
import Entitys.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Cityframe extends JFrame implements MouseListener, ActionListener
{
	ImageIcon img;
	JLabel selectCity,selectZone,address,imgLabel;
	JTextField addressfield;
	JButton exit,confirm,next,pr;
	JRadioButton r1, r2, r3,r4,r5;
	JCheckBox c1,c2, c3,c4,c5;
	ButtonGroup bg1;
	JComboBox combo;
	JPanel panel;
	Color myColor;
	Font myFont;

	public  Cityframe()
	{
		super("E-Outlet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		
		
		myColor = new Color(240,236,225);
		myFont = new Font("Cambria", Font.PLAIN,30);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(myColor);
		
		selectCity = new JLabel("Select City ");
		selectCity.setBounds(225,110,180,40);
		selectCity.setBackground(Color.LIGHT_GRAY);
		selectCity.setOpaque(true);
		selectCity.setForeground(Color.BLACK);
		selectCity.setFont(myFont);
		panel.add(selectCity);
		
		
		selectZone = new JLabel("Select Zone ");
		selectZone.setBounds(755,110,180,40);
		selectZone.setBackground(Color.LIGHT_GRAY);
		selectZone.setOpaque(true);
		selectZone.setForeground(Color.BLACK);
		selectZone.setFont(myFont);
		panel.add(selectZone);
		
		address = new JLabel("Enter Address:");
		address.setBounds(80,370,205,40);
		address.setBackground(Color.LIGHT_GRAY);
		address.setOpaque(true);
		address.setForeground(Color.BLACK);
		address.setFont(myFont);
		panel.add(address);
		
		addressfield=new JTextField();
		addressfield.setBounds(293,370,650,40);
		panel.add(addressfield);
		
		
		exit= new JButton("Exit");
		exit.setBounds(250,600,70,45);
		exit.setBackground(Color.LIGHT_GRAY);
		exit.addMouseListener(this);
		exit.addActionListener(this);
		panel.add(exit);
		
		next=new JButton("next");
		next.setBounds(460,600,60,50);
		next.setBackground(Color.LIGHT_GRAY);
		next.addMouseListener(this);
		next.addActionListener(this);
		panel.add(next);
		
		pr=new JButton("Previous");
		pr.setBounds(670,600,60,50);
		pr.setBackground(Color.LIGHT_GRAY);
		pr.addActionListener(this);
		panel.add(pr);
		
		confirm= new JButton("Confirm Address");
        confirm.setBounds(880,600,150,45);
		confirm.setBackground(Color.LIGHT_GRAY);
		confirm.addMouseListener(this);
		confirm.addActionListener(this);
		panel.add(confirm);
		
		r1 = new JRadioButton("Dhaka");
		r1.setBounds(225,170, 90,45);
		panel.add(r1);
		
		r2 = new JRadioButton("Chittagong");
		r2.setBounds(225,200, 90,45);
		panel.add(r2);
		
		r3 = new JRadioButton("Sylhet");
		r3.setBounds(225, 230, 90,45);
		panel.add(r3); 
		
		r4 = new JRadioButton("Khulna");
		r4.setBounds(225,260, 90,45);
		panel.add(r4);
		
		r5 = new JRadioButton("Rangpur");
		r5.setBounds(225,290, 90,45);
		panel.add(r5);
		
		bg1 = new ButtonGroup();
		bg1.add(r1);
		bg1.add(r2);
		bg1.add(r3);
		bg1.add(r4);
		bg1.add(r5);
		
		c1 = new JCheckBox("Banani");
		c1.setBounds(755,170, 90,45);
		panel.add(c1);
		
		c2 = new JCheckBox("Gulshan");
		c2.setBounds(755,200, 90,45);
		panel.add(c2);
		
		c3 = new JCheckBox("Mirpur");
		c3.setBounds(755,230, 90,45);
		panel.add(c3);
		
		c4 = new JCheckBox("Uttara");
		c4.setBounds(755,260, 90,45);
		panel.add(c4);
		
		c5 = new JCheckBox("Bashundhara");
		c5.setBounds(755,290, 90,45);
		panel.add(c5);
		
		
		String items[] = {"City", "Zone", "Address"};
		combo = new JComboBox(items);
		combo.setBounds(80,50,80,45);
		panel.add(combo);
		
		this.add(panel);
		
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me)
	{
		 if(me.getSource() == exit)
		{
			exit.setBackground(Color.BLUE);
			exit.setForeground(Color.WHITE);
		}
		 else if(me.getSource() == next)
		{
			next.setBackground(Color.BLUE);
			next.setForeground(Color.WHITE);
		}
		else if(me.getSource() == pr)
		{
			pr.setBackground(Color.BLUE);
			pr.setForeground(Color.WHITE);
		}
		 else if(me.getSource() ==confirm)
		{
			confirm.setBackground(Color.BLUE);
			confirm.setForeground(Color.WHITE);
		}
		else
		{
			
		}
	}
	public void mouseExited(MouseEvent me)
	{
		
	 if(me.getSource() == exit)
		{
			exit.setBackground(Color.LIGHT_GRAY);
			exit.setForeground(Color.BLACK);
		}
		else if(me.getSource() == next)
		{
			next.setBackground(Color.LIGHT_GRAY);
			next.setForeground(Color.BLACK);
		}
		else if(me.getSource() == confirm)
		{
			confirm.setBackground(Color.LIGHT_GRAY);
			confirm.setForeground(Color.BLACK);
		}
		else if(me.getSource() == pr)
		{
			pr.setBackground(Color.LIGHT_GRAY);
			pr.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
	public void actionPerformed(ActionEvent ae)
	{ 
		String s1=addressfield.getText();
		
		if(ae.getSource()==confirm)
		{
			if(s1.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All");
			}
		
		else
		{
			JOptionPane.showMessageDialog(this,"Now you can do payment in next page");
		}
		}
	    String command=ae.getActionCommand();
		if(ae.getSource()==next)
		{
			next.setBackground(Color.BLUE);
			Paymentframe f1=new  Paymentframe();
			f1.setVisible(true);
			this.setVisible(false);
			
	}
	else if(ae.getSource()==pr)
		{
			next.setBackground(Color.BLUE);
			JarinFrame f1=new  JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);
			
	}
	if(exit.getText().equals(command))
		{
			System.exit(0);
		}	
		else
		{
			
		}	
	}	
}