package classes;
import Entitys.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrameIntro extends JFrame implements MouseListener,ActionListener
{
	JFrame frame;
	JPanel panel;
	JLabel wristWatch,material,color,resistance,label;
	JButton next,back;
	Color mycolor,mycolor2,mycolor3,mycolor4,mycolor5;
	Font myfont;
	
	public FrameIntro()
	{
		super("E-Outlet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		
		mycolor=new Color(220,236,225);
		mycolor2=new Color(210,220,220);
		mycolor3=new Color(190,210,214);
		mycolor4=new Color(180,200,210);
		mycolor5=new Color(170,190,200);
		myfont=new Font("Cambria",Font.PLAIN,36);
		
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		ImageIcon img=new ImageIcon("image/WATCH.JPG");
		label=new JLabel("",img,JLabel.CENTER);
		label.setBounds(50,80,340,340);
	 	panel.add(label);
		
		wristWatch=new JLabel("Wrist Watch-$16/piece");
		wristWatch.setBounds(660,170,400,50);
		wristWatch.setBackground(mycolor2);
		wristWatch.setFont(myfont);
		wristWatch.setOpaque(true);
	 	panel.add(wristWatch);
		
		material=new JLabel("Material:Bronze");
		material.setBounds(660,220,400,50);
		material.setBackground(mycolor3);
		material.setFont(myfont);
		material.setOpaque(true);
		panel.add(material);
		
		color=new JLabel("Color:Metallic Bronze");
		color.setBounds(660,270,400,50);
		color.setBackground(mycolor4);
		color.setFont(myfont);
		color.setOpaque(true);
		panel.add(color);
		
		resistance=new JLabel("Corrosion Resistance");
		resistance.setBounds(660,320,400,50);
		resistance.setBackground(mycolor5);
		resistance.setFont(myfont);
		resistance.setOpaque(true);
		panel.add(resistance);
		
		next=new JButton("Start Order");
		next.setBounds(380,470,120,50);
		next.setBackground(Color.LIGHT_GRAY);
		next.addMouseListener(this);
		next.addActionListener(this);
		panel.add(next);
		
	    back=new JButton("Previous");
		back.setBounds(720,470,110,50);
		back.setBackground(Color.LIGHT_GRAY);
		back.addMouseListener(this);
		back.addActionListener(this);
		panel.add(back);
		
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.BLACK);
			next.setForeground(Color.WHITE);
		}
		else
		{
			
		}
		
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.LIGHT_GRAY);
			next.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(ae.getSource()==back)
		{
			back.setBackground(Color.BLUE);
			
			JarinFrame f1=new  JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==next)
		{
			next.setBackground(Color.BLUE);
			
			Cityframe f1=new  Cityframe();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else
		{
	    }
}
}