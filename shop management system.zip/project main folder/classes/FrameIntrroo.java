package classes;
import Entitys.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrameIntrroo extends JFrame implements MouseListener,ActionListener
{
	JFrame frame;
	JPanel panel;
	JLabel noteBook,material,color,durability,label;
	JButton next,back;
	Color mycolor,mycolor2,mycolor3,mycolor4,mycolor5;
	Font myfont;
	
	public FrameIntrroo()
	{
		super("E-Outlet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		
		mycolor=new Color(220,236,225);
		mycolor2=new Color(219,220,210);
		mycolor3=new Color(210,210,204);
		mycolor4=new Color(205,205,200);
		mycolor5=new Color(199,199,199);
		myfont=new Font("Cambria",Font.PLAIN,36);
		
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		ImageIcon img=new ImageIcon("image/STAT.JPG");
		label=new JLabel("",img,JLabel.CENTER);
		label.setBounds(50,80,340,340);
	 	panel.add(label);
		
		noteBook=new JLabel("Note Book-$7/piece");
		noteBook.setBounds(660,170,410,50);
		noteBook.setBackground(mycolor2);
		noteBook.setFont(myfont);
		noteBook.setOpaque(true);
	 	panel.add(noteBook);
		
		material=new JLabel("Material:Paper");
		material.setBounds(660,220,410,50);
		material.setBackground(mycolor3);
		material.setFont(myfont);
		material.setOpaque(true);
		panel.add(material);
		
		color=new JLabel("Color:White");
		color.setBounds(660,270,410,50);
		color.setBackground(mycolor4);
		color.setFont(myfont);
		color.setOpaque(true);
		panel.add(color);
		
		durability=new JLabel("Writting Comfort");
		durability.setBounds(660,320,410,50);
		durability.setBackground(mycolor5);
		durability.setFont(myfont);
		durability.setOpaque(true);
		panel.add(durability);
		
		next=new JButton("Start Order");
		next.setBounds(380,470,120,50);
		next.setBackground(Color.LIGHT_GRAY);
		next.addMouseListener(this);
		next.addActionListener(this);
		panel.add(next);
		
		back=new JButton("Previous");
		back.setBounds(720,470,110,50);
		back.setBackground(Color.LIGHT_GRAY);
	    back.addMouseListener(this);
		back.addActionListener(this);
		panel.add(back);
		
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.WHITE);
			next.setForeground(Color.BLACK);
		}
		else
		{
			
		}
		
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.LIGHT_GRAY);
			next.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(ae.getSource()==back)
		{
			back.setBackground(Color.BLUE);
			
			JarinFrame f1=new  JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);
		}
	else if(ae.getSource()==next)
		{
			next.setBackground(Color.BLUE);
			
			Cityframe f1=new  Cityframe();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else
		{
	    }
}
}
	