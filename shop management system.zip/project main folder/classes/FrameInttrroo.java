
package classes;
import Entitys.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrameInttrroo extends JFrame implements MouseListener,ActionListener
{
	JFrame frame;
	JPanel panel;
	JLabel noteBook,material,color,durability,label;
	JButton next,back;
	Color mycolor,mycolor2,mycolor3,mycolor4,mycolor5;
	Font myfont;
	
	public FrameInttrroo()
	{
		super("E-Outlet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		
		mycolor=new Color(230,236,225);
		mycolor2=new Color(220,230,215);
		mycolor3=new Color(210,220,205);
		mycolor4=new Color(200,210,200);
		mycolor5=new Color(190,200,190);
		myfont=new Font("Cambria",Font.PLAIN,36);
		
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		ImageIcon img=new ImageIcon("image/PERF.JPG");
		label=new JLabel("",img,JLabel.CENTER);
		label.setBounds(50,80,340,340);
	 	panel.add(label);
		
		noteBook=new JLabel("Perfume-$70/piece");
		noteBook.setBounds(660,170,430,50);
		noteBook.setBackground(mycolor2);
		noteBook.setFont(myfont);
		noteBook.setOpaque(true);
	 	panel.add(noteBook);
		
		material=new JLabel("Ingredients-Citron,Clary");
		material.setBounds(660,220,430,50);
		material.setBackground(mycolor3);
		material.setFont(myfont);
		material.setOpaque(true);
		panel.add(material);
		
		color=new JLabel("Company-Chanel");
		color.setBounds(660,270,430,50);
		color.setBackground(mycolor4);
		color.setFont(myfont);
		color.setOpaque(true);
		panel.add(color);
		
		durability=new JLabel("Long Lasting Scent");
		durability.setBounds(660,320,430,50);
		durability.setBackground(mycolor5);
		durability.setFont(myfont);
		durability.setOpaque(true);
		panel.add(durability);
		
		next=new JButton("Start Order");
		next.setBounds(380,470,120,50);
		next.setBackground(Color.LIGHT_GRAY);
		next.addMouseListener(this);
		next.addActionListener(this);
		panel.add(next);
		
		back=new JButton("Previous");
		back.setBounds(720,470,110,50);
		back.setBackground(Color.LIGHT_GRAY);
	    back.addMouseListener(this);
		back.addActionListener(this);
		panel.add(back);
		
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.BLACK);
			next.setForeground(Color.WHITE);
		}
		else
		{
			
		}
		
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==next)
		{
			next.setBackground(Color.LIGHT_GRAY);
			next.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(ae.getSource()==back)
		{
			back.setBackground(Color.BLUE);
			
			JarinFrame f1=new  JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==next)
		{
			next.setBackground(Color.BLUE);
			
			Cityframe f1=new  Cityframe();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else
		{
	    }
	}
}