package classes;
import Entitys.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JarinFrame extends JFrame implements MouseListener,ActionListener
{
	JFrame frame;
	JPanel panel;
	JLabel search,label,l,l1,l2,l3;
	JTextField searchfield;
	JButton bags,watch,stationeries,sunglass,perfume,pr;
	Color mycolor,mycolor2;
	Font myfont,myfont2;
	
	public JarinFrame()
	{
		super("e-Outlet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		
		mycolor=new Color(240,236,225);
		mycolor2=new Color(250,220,220);
		
		myfont=new Font("Cambria",Font.PLAIN,36);
		myfont2=new Font("Cambria",Font.PLAIN,48);
		
		panel=new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		search=new JLabel("Search");
		search.setBounds(70,70,150,60);
		search.setBackground(mycolor2);
		search.setFont(myfont);
		search.setOpaque(true);
		panel.add(search);
		
		searchfield=new JTextField(" ");
		searchfield.setBounds(235,70,600,60);
		panel.add(searchfield);
		
		ImageIcon img=new ImageIcon("image/BAG.JPG");
		label=new JLabel("",img,JLabel.CENTER);
		label.setBounds(3,150,260,260);
	 	panel.add(label);
		
		ImageIcon im=new ImageIcon("image/WAT.JPG");
		l3=new JLabel("",im,JLabel.CENTER);
		l3.setBounds(260,167,230,220);
	 	panel.add(l3);
		
		ImageIcon imge=new ImageIcon("image/STA.JPG");
		l=new JLabel("",imge,JLabel.CENTER);
		l.setBounds(520,150,250,300);
	 	panel.add(l);
		
		ImageIcon imag=new ImageIcon("image/SU.JPG");
		l1=new JLabel("",imag,JLabel.CENTER);
		l1.setBounds(800,150,260,260);
	 	panel.add(l1);
		
		ImageIcon image=new ImageIcon("image/PER.JPG");
		l2=new JLabel("",image,JLabel.CENTER);
		l2.setBounds(1080,150,260,260);
	 	panel.add(l2);
		
		bags=new JButton("Bags");
		bags.setBounds(35,500,150,50);
		bags.setBackground(Color.CYAN);
		bags.addMouseListener(this);
		bags.addActionListener(this);
		panel.add(bags);
		
		watch=new JButton("Watch");
		watch.setBounds(310,500,150,50);
		watch.setBackground(Color.CYAN);
		watch.addMouseListener(this);
		watch.addActionListener(this);
		panel.add(watch);
		
		
		stationeries=new JButton("Stationeries");
		stationeries.setBounds(590,500,150,50);
		stationeries.setBackground(Color.CYAN);
		stationeries.addMouseListener(this);
		stationeries.addActionListener(this);
		panel.add(stationeries);
		
		sunglass=new JButton("Sunglass");
		sunglass.setBounds(870,500,150,50);
		sunglass.setBackground(Color.CYAN);
		sunglass.addMouseListener(this);
		sunglass.addActionListener(this);
		panel.add(sunglass);
		
		perfume=new JButton("Perfume");
		perfume.setBounds(1150,500,150,50);
		perfume.setBackground(Color.CYAN);
		perfume.addMouseListener(this);
		perfume.addActionListener(this);
		panel.add(perfume);
		
		pr=new JButton("<");
		pr.setBounds(1100,80,100,50);
		pr.setBackground(Color.WHITE);
		pr.setFont(myfont2);
		pr.addMouseListener(this);
		pr.addActionListener(this);
		panel.add(pr);
		
		
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==bags)
		{
			bags.setBackground(Color.PINK);
			bags.setForeground(Color.WHITE);
		}
		else if(me.getSource()==watch)
		{
			watch.setBackground(Color.PINK);
			watch.setForeground(Color.WHITE);
			
		}
		else if(me.getSource()==stationeries)
		{
			stationeries.setBackground(Color.PINK);
			stationeries.setForeground(Color.WHITE);
		}
		else if(me.getSource()==sunglass)
		{
			sunglass.setBackground(Color.PINK);
			sunglass.setForeground(Color.WHITE);
		}
		else if(me.getSource()==perfume)
		{
			perfume.setBackground(Color.PINK);
			perfume.setForeground(Color.WHITE);
		}
		else if(me.getSource()==pr)
		{
			pr.setBackground(Color.PINK);
			pr.setForeground(Color.WHITE);
		}
		else
		{
			
		}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==bags)
		{
			bags.setBackground(Color.WHITE);
			bags.setForeground(Color.BLACK);
		}
		else if(me.getSource()==watch)
		{
			watch.setBackground(Color.WHITE);
			watch.setForeground(Color.BLACK);
		
		}
		else if(me.getSource()==stationeries)
		{
			stationeries.setBackground(Color.WHITE);
			stationeries.setForeground(Color.BLACK);
		}
		else if(me.getSource()==sunglass)
		{
			sunglass.setBackground(Color.WHITE);
			sunglass.setForeground(Color.BLACK);
		}
		else if(me.getSource()==perfume)
		{
			perfume.setBackground(Color.WHITE);
			perfume.setForeground(Color.BLACK);
		}
		else if(me.getSource()==pr)
		{
			pr.setBackground(Color.WHITE);
			pr.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
		public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(ae.getSource()==bags)
		{
			bags.setBackground(Color.BLUE);
			
			Intro f1=new  Intro();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==watch)
		{
			watch.setBackground(Color.BLUE);
			
			FrameIntro f1=new FrameIntro();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==stationeries)
		{
			stationeries.setBackground(Color.BLUE);
			
		    FrameIntrroo f1=new FrameIntrroo();
			f1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==sunglass)
		{
			stationeries.setBackground(Color.BLUE);
			
		    FrameIntrrroo f1=new FrameIntrrroo();
			f1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==perfume)
		{
			perfume.setBackground(Color.BLUE);
			
		    FrameInttrroo f1=new FrameInttrroo();
			f1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==pr)
		{
			pr.setBackground(Color.BLUE);
			
		    Rudiyaframe f1=new Rudiyaframe();
			f1.setVisible(true);
			this.setVisible(false);
			
		}
		else  {
	}
	}
}