package classes;
import Entitys.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Paymentframe extends JFrame implements MouseListener,ActionListener
{
	JFrame frame;
	JPanel panel;
	Color mycolor,mycolor2;
	Font myfont;
	JLabel cardno,secu,label,l,l3;
	JTextField cardnoTF,secuTF;
	JRadioButton v,m,u;
	ButtonGroup bg1;
	JComboBox month,year;
	JButton submit,pr,exit;
	
	public Paymentframe()
	{
		super("e-OutLet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		
		mycolor=new Color(209,220,216);
		mycolor2=new Color(200,225,220);
		myfont=new Font("Roboto",Font.PLAIN,42);
		
			panel=new JPanel();
			panel.setLayout(null);
			panel.setBackground(mycolor);
			
			secu=new JLabel("Select Card Type");
			secu.setBounds(50,50,200,50);
			panel.add(secu);
			
			m=new JRadioButton("");
			m.setBounds(50,100,60,50);
			m.setBackground(mycolor2);
			m.addMouseListener(this);
		    m.addActionListener(this);
			m.setSelected(true);
			panel.add(m);
			
			v=new JRadioButton("");
			v.setBounds(350,100,60,50);
			v.setBackground(mycolor2);
			v.addMouseListener(this);
			v.addActionListener(this);
			v.setSelected(true);
			panel.add(v);
			
			u=new JRadioButton("");
			u.setBounds(650,100,60,50);
			u.setBackground(mycolor2);
			u.addMouseListener(this);
			u.addActionListener(this);
			u.setSelected(true);
			panel.add(u);
			
			bg1=new ButtonGroup();
			bg1.add(m);
			bg1.add(v);
			bg1.add(u);
			
		ImageIcon img=new ImageIcon("image/MAS.JPG");
		label=new JLabel("",img,JLabel.CENTER);
		label.setBounds(110,100,120,70);
	 	panel.add(label);
		
		ImageIcon im=new ImageIcon("image/CR.JPG");
		l3=new JLabel("",im,JLabel.CENTER);
		l3.setBounds(710,100,125,70);
	 	panel.add(l3);
		
		ImageIcon imge=new ImageIcon("image/VISA.JPG");
		l=new JLabel("",imge,JLabel.CENTER);
		l.setBounds(410,100,100,70);
	 	panel.add(l);
		
			
			cardno=new JLabel("Card Number ");
			cardno.setBounds(50,180,200,50);
			panel.add(cardno);
			
			cardnoTF=new JTextField();
			cardnoTF.setBounds(50,240,500,50);
	        panel.add(cardnoTF);
			
			secu=new JLabel("Security Code");
			secu.setBounds(700,180,200,50);
			panel.add(secu);
			
			secuTF=new JTextField();
			secuTF.setBounds(700,240,500,50);
			panel.add(secuTF);
			
			secu=new JLabel("Expiration Date");
			secu.setBounds(50,320,100,50);
			panel.add(secu);
			
			String months[]={"Jan","Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec"};
			String years[]={"2058","2057","2056","2055","2054","2053","2052","2051","2050","2049","2048","2047","2046","2045","2044","2043","2042","2041","2040"};
			
		
			month=new JComboBox(months);
			month.setBounds(50,370,200,50);
			panel.add(month);
			year=new JComboBox(years);
			year.setBounds(500,370,200,50);
			panel.add(year);
			
			
			secu=new JLabel("First Name");
			secu.setBounds(50,420,200,50);
			panel.add(secu);
			
			secuTF=new JTextField();
			secuTF.setBounds(50,480,500,50);
			panel.add(secuTF);
			
			secu=new JLabel("Last Name");
			secu.setBounds(700,420,200,50);
			panel.add(secu);
			
			secuTF=new JTextField();
			secuTF.setBounds(700,480,500,50);
			panel.add(secuTF);
	
			
			submit=new JButton("Submit");
			submit.setBounds(350,590,100,45);
			submit.setBackground(Color.LIGHT_GRAY);
			submit.addMouseListener(this);
			submit.addActionListener(this);
			panel.add(submit);
			
			
		    exit= new JButton("Exit");
		    exit.setBounds(650,590,100,45);
		    exit.setBackground(Color.LIGHT_GRAY);
		    exit.addMouseListener(this);
		    exit.addActionListener(this);
		    panel.add(exit);
			
			pr=new JButton("<");
			pr.setBounds(1050,100,100,45);
			pr.setBackground(Color.WHITE);
			pr.addMouseListener(this);
			pr.addActionListener(this);
			panel.add(pr);
			
		this.add(panel);
		
	}
	    public void mouseClicked(MouseEvent me){}
		public void mousePressed(MouseEvent me){}
		public void mouseReleased(MouseEvent me){}
		public void mouseEntered(MouseEvent me)
		{
			
			if(me.getSource()==submit)
			{
			submit.setBackground(Color.BLUE);
			submit.setForeground(Color.WHITE);
			}
			else if(me.getSource() == exit)
		    {
			exit.setBackground(Color.BLUE);
			exit.setForeground(Color.WHITE);
		    }
			else if(me.getSource()==pr)
			{
			pr.setBackground(Color.BLUE);
			pr.setForeground(Color.WHITE);
			}
			else
			{
			}
		}
		public void mouseExited(MouseEvent me)
		{
			
			if(me.getSource()==submit)
			{
			
			submit.setBackground(Color.WHITE);
			submit.setForeground(Color.BLACK);
			}
			else if(me.getSource() == exit)
		    {
			exit.setBackground(Color.WHITE);
			exit.setForeground(Color.BLACK);
		    }
			else if(me.getSource()==pr)
			{
			
			pr.setBackground(Color.WHITE);
			pr.setForeground(Color.BLACK);
			}
			
			else
			{
			}
		}
   public void actionPerformed(ActionEvent ae)
		{  
		String s1=cardnoTF.getText();
		String s2=secuTF.getText();
		
		if(ae.getSource()==submit)
		{
			if(s1.isEmpty()||s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All");
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Order Confirmed");
			} 				
		}
		String command=ae.getActionCommand();
		if(ae.getSource()==pr)
		{
			pr.setBackground(Color.BLUE);
			JarinFrame f1=new  JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);	
	}	
	    if(exit.getText().equals(command))
		{
			System.exit(0);
		}	
		else
		{
			
		}	
	}
	}
