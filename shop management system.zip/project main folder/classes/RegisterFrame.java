package classes;
import Entitys.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterFrame extends JFrame implements MouseListener,ActionListener
{
	JPanel panel;
	Color mycolor,mycolor2;
	Font myfont;
	JLabel namelb,emaillb,genderlb,doblb,addresslb,pslabel;
	JTextField nameTF,emailTF,phoneTF;
	JPasswordField psTF;
	JRadioButton male,female;
	ButtonGroup bg1;
	JComboBox day,month,year;
	JTextArea t1;
	JCheckBox terms;
	JButton submit;
	
	public RegisterFrame()
	{
		super("e-OutLet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		mycolor=new Color(209,220,216);
		mycolor2=new Color(200,225,220);
		myfont=new Font("Roboto",Font.PLAIN,42);
		
			panel=new JPanel();
			panel.setLayout(null);
			panel.setBackground(mycolor);
			
			namelb=new JLabel("Name: ");
			namelb.setBounds(250,130,100,50); 
			panel.add(namelb);
			
			
			nameTF=new JTextField();
			nameTF.setBounds(430,130,500,50);
			panel.add(nameTF);
			
			pslabel=new JLabel("pass: ");
			pslabel.setBounds(1000,130,100,50);
			panel.add(pslabel);
			
			psTF=new JPasswordField();
			psTF.setBounds(1100,130,300,50);
			panel.add(psTF);
			
			emaillb=new JLabel("E-mail");
			emaillb.setBounds(250,210,100,50);
			
			panel.add(emaillb);
			
			emailTF=new JTextField();
			emailTF.setBounds(430,210,500,50);
			panel.add(emailTF);
			
			
			genderlb=new JLabel("Gender");
			genderlb.setBounds(250,290,100,50);
			panel.add(genderlb);
			
			male=new JRadioButton("Male");
			male.setBounds(430,290,100,50);
			male.setBackground(mycolor2);
			male.addMouseListener(this);
		    male.addActionListener(this);
			male.setSelected(true);
			panel.add(male);
			
			female=new JRadioButton("Female");
			female.setBounds(570,290,100,50);
			female.setBackground(mycolor2);
			female.addMouseListener(this);
			female.addActionListener(this);
			female.setSelected(true);
			panel.add(female);
			
			bg1=new ButtonGroup();
			bg1.add(male);
			bg1.add(female);
			
			doblb=new JLabel("Date of birth");
			doblb.setBounds(250,370,100,50);
			panel.add(doblb);
			
			String days[]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"};
			String months[]={"Jan","Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec"};
			String years[]={"2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998"};
			
			
			day=new JComboBox(days);
			day.setBounds(430,370,100,50);
			panel.add(day);
			month=new JComboBox(months);
			month.setBounds(650,370,100,50);
			panel.add(month);
			year=new JComboBox(years);
			year.setBounds(870,370,100,50);
			panel.add(year);
			
			addresslb=new JLabel("Address");
			addresslb.setBounds(250,450,100,50);
			panel.add(addresslb);
			
			t1=new JTextArea();
			t1.setBounds(430,450,500,50);
			panel.add(t1);
			
			terms=new JCheckBox("Accept all terms and conditions");
			terms.setBounds(250,530,220,45);
			panel.add(terms);
			
			submit=new JButton("Submit");
			submit.setBounds(300,630,100,45);
			submit.setBackground(Color.BLUE);
			submit.addMouseListener(this);
			submit.addActionListener(this);
			panel.add(submit);
			
		
		
		this.add(panel);
		
	}
	    public void mouseClicked(MouseEvent me){}
		public void mousePressed(MouseEvent me){}
		public void mouseReleased(MouseEvent me){}
		public void mouseEntered(MouseEvent me)
		{
			
			if(me.getSource()==submit)
			{
			submit.setBackground(Color.BLUE);
			submit.setForeground(Color.WHITE);
			}
			else
			{
			}
		}
		public void mouseExited(MouseEvent me)
		{
			
			if(me.getSource()==submit)
			{
			
			submit.setBackground(Color.WHITE);
			submit.setForeground(Color.BLACK);
			}
			else
			{
			}
		}
   public void actionPerformed(ActionEvent ae)
		{
			String s1=nameTF.getText();
			String s2=psTF.getText();
		
		if(ae.getSource()==submit)
		{
			if(s1.isEmpty()||s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All");
			}
			else{
				Account a1=new Account(s1,s2);
				a1.addAccount();
				Signinframe f1=new Signinframe();
				f1.setVisible(true);
				this.setVisible(false);
			JOptionPane.showMessageDialog(this,"Successfully registered");
			}
		}
			

}
}
			
	