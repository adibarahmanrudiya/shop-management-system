package classes;
import Entitys.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Rudiyaframe extends JFrame implements MouseListener,ActionListener

{
		
		JPanel panel;
		JLabel background;
		JButton getstartedbtn,registerbtn;
		Color mycolor;
		Font myfont;
		ImageIcon background_image;
		
		
		public Rudiyaframe()
		{
			
			//frame
			super("e-OutLet");//project name
			this.setSize(1600,1800);
			this.setLocation(0,0);
			
			
			
			mycolor=new Color(225,225,225);
			myfont=new Font("Segoe UI", Font.BOLD, 68);
			
			panel=new JPanel();
			panel.setLayout(null);
			panel.setBackground(mycolor);
			panel.setFont(myfont);
			
			
			
		
			
			getstartedbtn=new JButton("Welcome");
			getstartedbtn.setBounds(190,300,400,90);
			getstartedbtn.setBackground(Color.GRAY);
			getstartedbtn.setFont(myfont);
			
			getstartedbtn.addMouseListener(this);
			getstartedbtn.addActionListener(this);
			
			
			
			
			panel.add(getstartedbtn);
			
			
			
			
			//background image
			ImageIcon background_image=new ImageIcon("image/ONL.JPG");
			Image img = background_image.getImage();
			JLabel background=new JLabel("",background_image,JLabel.CENTER);
			background.setBounds(660,1,900,900);
			panel.add(background);
			
			this.add(panel);
		}
		public void mouseClicked(MouseEvent me){}
		public void mousePressed(MouseEvent me){}
		public void mouseReleased(MouseEvent me){}
		public void mouseEntered(MouseEvent me)
		{
			
			if(me.getSource()==getstartedbtn)
			{
			getstartedbtn.setBackground(Color.GRAY);
			getstartedbtn.setForeground(Color.WHITE);
			}
			else if(me.getSource()==registerbtn)
			{
			registerbtn.setBackground(Color.BLUE);
			registerbtn.setForeground(Color.WHITE);
			}
			else
			{
			}
		}
		public void mouseExited(MouseEvent me)
		{
			
			if(me.getSource()==getstartedbtn)
			{
			
			getstartedbtn.setBackground(Color.WHITE);
			getstartedbtn.setForeground(Color.BLACK);
			}
			else if(me.getSource()==registerbtn)
			{
			registerbtn.setBackground(Color.WHITE);
			registerbtn.setForeground(Color.BLACK);
			}
			else
			{
			}
		}
		public void actionPerformed(ActionEvent ae)
		{
			String command=ae.getActionCommand();
			if(ae.getSource()==getstartedbtn)
			{
				getstartedbtn.setBackground(Color.BLUE);
				Signinframe f1=new Signinframe();
				f1.setVisible(true);
				this.setVisible(false);
			}
		}
}
			
		

	
	
	
	
	
	
	
	
	