package classes;
import Entitys.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Signinframe extends JFrame implements MouseListener,ActionListener
{
	JPanel panel;
	JLabel userlb,passlb;
	JTextField userTF;
	JPasswordField passPF;
	JButton signinbtn,nextbtn,login;
	JRadioButton admin,customer;
	ButtonGroup bg1;
	Color mycolor,mycolor2;
	Font myfont;
	
	public Signinframe()
	{
		super("e-OutLet");
		this.setSize(1600,1800);
		this.setLocation(0,0);
		mycolor=new Color(209,228,236);
		mycolor2=new Color(209,228,236);
		myfont=new Font("Roboto",Font.PLAIN,50);
			
			panel=new JPanel();
			panel.setLayout(null);
			panel.setBackground(mycolor);		
			
			userlb=new JLabel("Username: ");
			userlb.setBounds(350,140,100,60);
			
			panel.add(userlb);
			
			userTF=new JTextField();
			userTF.setBounds(450,140,550,60);
			panel.add(userTF);
			
			passlb=new JLabel("Password: ");
			passlb.setBounds(350,250,100,60);
			panel.add(passlb);
			
			passPF=new JPasswordField();
			passPF.setBounds(450,250,550,60);
			passPF.setEchoChar('*');
			panel.add(passPF);
			
			admin=new JRadioButton("Admin");
			admin.setBounds(350,360,80,20);
			admin.setBackground(mycolor2);
			admin.addMouseListener(this);
		    admin.addActionListener(this);
			admin.setSelected(true);
			panel.add(admin);
			
			customer=new JRadioButton("Customer");
			customer.setBounds(500,360,120,20);
			customer.setBackground(mycolor2);
			customer.addMouseListener(this);
			customer.addActionListener(this);
			customer.setSelected(true);
			panel.add(customer);
			
			bg1=new ButtonGroup();
			bg1.add(admin);
			bg1.add(customer);
			
			signinbtn=new JButton("Signin");
			signinbtn.setBounds(280,500,100,60);
			signinbtn.setBackground(Color.ORANGE);
			signinbtn.addMouseListener(this);
			signinbtn.addActionListener(this);
			
			panel.add(signinbtn);
			
			login=new JButton("Login");
			login.setBounds(540,250,100,50);
			login.setBackground(Color.ORANGE);
			login.addMouseListener(this);
			login.addActionListener(this);
			
			panel.add(login);
			
			nextbtn=new JButton("Register");
			nextbtn.setBounds(570,500,100,60);
			nextbtn.setBackground(Color.RED);
			nextbtn.addMouseListener(this);
			nextbtn.addActionListener(this);
					
			panel.add(nextbtn);
			this.add(panel);
	}
	    public void mouseClicked(MouseEvent me){}
		public void mousePressed(MouseEvent me){}
		public void mouseReleased(MouseEvent me){}
		public void mouseEntered(MouseEvent me)
		{
			
			if(me.getSource()==signinbtn)
			{
			signinbtn.setBackground(Color.BLUE);
			signinbtn.setForeground(Color.WHITE);
			}
			else if(me.getSource()==nextbtn)
			{
			nextbtn.setBackground(Color.BLUE);
			nextbtn.setForeground(Color.WHITE);
			}
			else if(me.getSource()==login)
			{
			login.setBackground(Color.BLUE);
			login.setForeground(Color.WHITE);
			}
			else
			{
			}
		}
		public void mouseExited(MouseEvent me)
		{
			
			if(me.getSource()==signinbtn)
			{
			
			signinbtn.setBackground(Color.WHITE);
			signinbtn.setForeground(Color.BLACK);
			}
			else if(me.getSource()==nextbtn)
			{
			nextbtn.setBackground(Color.WHITE);
			nextbtn.setForeground(Color.BLACK);
			}
			else if(me.getSource()==login)
			{
			login.setBackground(Color.WHITE);
			login.setForeground(Color.BLACK);
			}
			else
			{
			}
		}
	public void actionPerformed(ActionEvent ae)
	{
		String s1=userTF.getText();
		String s2=passPF.getText();
		
		if(ae.getSource()==signinbtn)
		{
			if(s1.isEmpty()||s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All");
			}
			else{
		    Account a1=new Account(s1,s2);
			a1.addAccount();
			JarinFrame f1=new JarinFrame();
			f1.setVisible(true);
			this.setVisible(false);
			JOptionPane.showMessageDialog(this,"");
		}
			
			}
		 if(ae.getSource()==nextbtn)
		{  
	        nextbtn.setBackground(Color.BLUE);
			RegisterFrame f1=new RegisterFrame();
			f1.setVisible(true);
			this.setVisible(false);
		}
		else{
		}
	}
	
}